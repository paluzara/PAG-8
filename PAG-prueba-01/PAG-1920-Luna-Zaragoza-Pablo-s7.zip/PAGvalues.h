#pragma once

enum PAGstipomovimiento {
	PAG_TTILT,
	PAG_PAN,
	PAG_TRUCK,
	PAG_BOOM,
	PAG_ORBIT,
	PAG_ZOOM,
	PAG_NONE
};

enum PAGstipoluz {
	PUNTUAL,
	SPOT,
	AMBIENTE,
	MODELO
};
#include <iostream>
#include <GL\glew.h>
#include <string>
#include "Pagvao.h"
#include "Pagmaterial.h"





class Pagmodelo
{
	GLenum modoVisualizacion;
	Pagvao *vao;
	Pagmaterial *material;

public:
	enum tipoModelo {
		PAG_TRIANGULO,
		PAG_CUADRADO,
		PAG_TETRAEDRO,
		PAG_CUBO
	};

	void pintate();
	void setMaterial(glm::vec3 ka, glm::vec3 kd, glm::vec3 ks, float sh);
	void setMaterial(Pagmaterial* material);
	void setModoVisualizacion( GLenum modo );
	Pagmaterial * getMaterial();
	
	Pagmodelo(tipoModelo tipo);
	
	~Pagmodelo();

};


#pragma once

enum PAGstipomovimiento {
	PAG_TTILT,
	PAG_PAN,
	PAG_TRUCK,
	PAG_BOOM,
	PAG_ORBIT,
	PAG_ZOOM,
	PAG_NONE,
	PAG_MROT,
	PAG_MTRANS,
	PAG_MSCALE
};

enum PAGstipoluz {
	PUNTUAL,
	SPOT,
	AMBIENTE,
	MODELO
};